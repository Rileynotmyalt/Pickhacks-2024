var sideBar = document.getElementById("sidebar");

function createLabel(labelText) {
  var label = document.createElement("label");
  label.className = "sidebar-label";
  label.innerHTML = labelText;
  return label;
}

function createButton() {
  var button = document.createElement("button");
  button.className = "sidebar-button";
  button.innerHTML = "↓";
  return button;
}

