function tag() {
  const bottomBar = document.getElementById("bottombar");
  var tagtxt = document.createElement("label");
  tagtxt.className = 'bottombar-label'
  tagtxt.innerHTML = "test";
  var tag = document.createElement("input")
  //bottomBar.append(tagtxt)
  bottomBar.append(tag);
}

tag()