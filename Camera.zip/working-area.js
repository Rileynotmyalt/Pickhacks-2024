/* let firstDot = null; // Stores reference to the first clicked dot
let drawnLines = []; // Store references to drawn lines

function createDotOnClick(event) {
  const workingArea = document.getElementById("working-area");
  const dot = document.createElement("div");
  dot.className = "dot";

  const clickX = event.clientX - workingArea.getBoundingClientRect().left;
  const clickY = event.clientY - workingArea.getBoundingClientRect().top;
  dot.style.left = `${clickX}px`;
  dot.style.top = `${clickY}px`;

  dot.style.width = "5px"; // Adjust as needed
  dot.style.height = "5px"; // Adjust as needed
  dot.style.backgroundColor = "red"; // Adjust color

  workingArea.appendChild(dot);

  // Check if close to first dot and lines exist
  if (firstDot && isCloseEnough(firstDot, dot) && drawnLines.length > 0) {
    transformLinesToPolygon();
  } else {
    // Draw line if not close to first dot
    if (firstDot) {
      drawLine(firstDot, dot);
    }
  }

  // Update firstDot for subsequent clicks
  firstDot = dot;
}

function transformLinesToPolygon() {
  const polygon = document.createElement("polygon");
  polygon.style.background = "black"; // Set fill color

  // Create a path string for the polygon
  const path = drawnLines.map(line => {
    const box = line.getBoundingClientRect();
    return `${box.left} ${box.top}`;
  }).join(",");

  polygon.setAttribute("points", path);

  // Remove lines and append polygon
  drawnLines.forEach(line => line.remove());
  workingArea.appendChild(polygon);
  drawnLines = []; // Reset line storage
}


function drawLine(dot1, dot2) {
  const line = document.createElement("div");
  line.className = "line"; // Add class for styling

  // Calculate line starting and ending points based on dot positions
  var startX, startY, width, angle;

  if (dot1.offsetLeft < dot2.offsetLeft) {
    startX = dot1.offsetLeft;
    startY = dot1.offsetTop;
    var x = dot2.offsetLeft - dot1.offsetLeft;
    var y = dot2.offsetTop - dot1.offsetTop;
    width = Math.sqrt(x * x + y * y);
    angle = Math.atan2(y, x);
  } else {
    startX = dot2.offsetLeft;
    startY = dot2.offsetTop;
    var x = dot1.offsetLeft - dot2.offsetLeft;
    var y = dot1.offsetTop - dot2.offsetTop;
    width = Math.sqrt(x * x + y * y);
    angle = Math.atan2(y, x);
  }

  // Set line styles using calculated coordinates
  line.style.position = "absolute";
  line.style.left = `${startX}px`;
  line.style.top = `${startY}px`;
  line.style.width = `${width}px`; // Adjust for line thickness
  line.style.height = "2px"; // Adjust line thickness
  line.style.transformOrigin = "left";
  line.style.rotate = `${angle}rad`; // Adjust rotation for line
  line.style.backgroundColor = "black"; // Adjust line color

  workingArea.appendChild(line);
  drawnLines.push(line);
}


function isCloseEnough(dot1, dot2) {
  // Define a threshold distance for closeness
  const threshold = 25; // Adjust as needed (in pixels)

  const distanceX = Math.abs(dot1.offsetLeft - dot2.offsetLeft);
  const distanceY = Math.abs(dot1.offsetTop - dot2.offsetTop);

  // Check if both X and Y distances are within the threshold
  return distanceX <= threshold && distanceY <= threshold;
}



const workingArea = document.getElementById("working-area");

*/




let shapes = []
let startX = 0
let startY = 0
let endX = 0
let endY = 0
let selectedShape = "square" // Default selected shape
let drawingInProgress = false // To check if shape drawing is in progress
let currentShape = null // To store the currently drawn shape
let shapeColor = "red" // Default shape color for new shapes


// Function to create a square
function createSquare(startX, startY, endX, endY) {
  const squareElement = document.createElement("div")
  squareElement.classList.add("shape")
  squareElement.classList.add("square")
  squareElement.style.backgroundColor = shapeColor // Set shape color
  squareElement.style.width = Math.abs(endX - startX) + "px"
  squareElement.style.height = Math.abs(endY - startY) + "px"
  squareElement.style.left = Math.min(startX, endX) + "px"
  squareElement.style.top = Math.min(startY, endY) + "px"
  squareElement.setAttribute("data-present", "true") // Set data attribute to indicate presence
  return squareElement
}

// Creating a circle

function createCircle(startX, startY, endX, endY) {
  const radius = Math.sqrt((endX - startX) ** 2 + (endY - startY) ** 2)
  const circleElement = document.createElement("div")
  circleElement.classList.add("shape")
  circleElement.classList.add("circle")
  circleElement.style.backgroundColor = shapeColor // Set shape color
  circleElement.style.width = 2 * radius + "px"
  circleElement.style.height = 2 * radius + "px"
  circleElement.style.left = startX - radius + "px"
  circleElement.style.top = startY - radius + "px"
  circleElement.setAttribute("data-present", "true") // Set data attribute to indicate presence
  return circleElement
}

// Function to add shape on mousedown
function addShape(event) {
  if (!drawingInProgress) {
    drawingInProgress = true
    const container = document.getElementById("working-area")
    startX = event.clientX - container.getBoundingClientRect().left
    startY = event.clientY - container.getBoundingClientRect().top
  }
}

function resizeShape(event) {
  if (drawingInProgress) {
    const container = document.getElementById("working-area")
    endX = event.clientX - container.getBoundingClientRect().left
    endY = event.clientY - container.getBoundingClientRect().top
    let shape
    if (selectedShape === "circle") {
      shape = createCircle(startX, startY, endX, endY)
    } else {
      shape = createSquare(startX, startY, endX, endY)
    }
    if (currentShape) {
      container.removeChild(currentShape)
    }
    currentShape = shape
    container.appendChild(shape)
  }
}

function stopResizing() {
  if (drawingInProgress) {
    drawingInProgress = false
    if (currentShape) {
      shapes.push(currentShape)
      currentShape.setAttribute("data-present", "true") // Set data attribute to indicate presence
      displayShapeInfo(startX, startY, endX, endY, shapeColor)
      currentShape = null
    }
  }
}


/* // Function to display shape information
function displayShapeInfo(startX, startY, endX, endY, shapeColor) {
  const shapeInfo = document.getElementById("shapeInfo")
  const shapeType =
    selectedShape.charAt(0).toUpperCase() + selectedShape.slice(1) 
  const info = document.createElement("div")
  if (shapeColor == "red") {
    info.textContent = `${shapeType}: Start (${startX}, ${startY}), End (${endX}, ${endY}) Type: Exterior Walls`
  } else if (shapeColor == "blue") {
    info.textContent = `${shapeType}: Start (${startX}, ${startY}), End (${endX}, ${endY}) Type: Placeable Zones`
  } else if (shapeColor == "green") {
    info.textContent = `${shapeType}: Start (${startX}, ${startY}), End (${endX}, ${endY}) Type: Door`
  } else if (shapeColor == "purple") {
    info.textContent = `${shapeType}: Start (${startX}, ${startY}), End (${endX}, ${endY}) Type: Car`
  } else if (shapeColor == "yellow") {
    info.textContent = `${shapeType}: Start (${startX}, ${startY}), End (${endX}, ${endY}) Type: Window`
  } else {
    info.textContent = `${shapeType}: Start (${startX}, ${startY}), End (${endX}, ${endY}) Color ${shapeColor}`
  }
  shapeInfo.appendChild(info)
} */

// Function to delete the most recent shape
function deleteShape() {
  const shapeInfo = document.getElementById("shapeInfo")
  const lastShapeIndex = shapes.length - 1
  if (lastShapeIndex >= 0) {
    const shapeToRemove = shapes[lastShapeIndex]
    if (shapeToRemove.getAttribute("data-present") === "true") {
      shapeToRemove.parentNode.removeChild(shapeToRemove) // Remove shape from DOM
      shapes.pop() // Remove shape from shapes array
      shapeInfo.removeChild(shapeInfo.lastChild) // Remove the most recent shape info line
    }
  }
}


// Function to change the color of the shapes
function changeShapeColor(color) {
  shapeColor = color
}


// Function to select the shape
function selectShape(shape) {
  selectedShape = shape
  document.querySelectorAll(".shape-buttons button") // Reset all button styles
  document.getElementById(selectedShape + "Button")
}

// Add event listener to the container for adding shapes on mousedown
document.getElementById("working-area").addEventListener("mousedown", addShape)

// Add event listener to the document for resizing shape on mousemove
document.addEventListener("mousemove", resizeShape)

// Add event listener to the document for stopping resizing on mouseup
document.addEventListener("mouseup", stopResizing)

// Show mouse coordinates when hovering over the image

// Call selectShape to set the default shape
selectShape("square")

