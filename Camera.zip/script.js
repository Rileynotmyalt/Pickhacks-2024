var step = 0;

document.addEventListener("DOMContentLoaded", function() {
  var sidebar = document.getElementById("sidebar");
  var workingArea = document.getElementById("working-area");
  var bottomBar = document.getElementById("bottombar");

  var Label1 = createLabel("1.) Build the Property");
  Label1.style.top = "2%";
  sidebar.append(Label1);

  var Label2 = createLabel("2.) Label Area");
  Label2.style.top = "27%";
  sidebar.append(Label2);

  var Label3 = createLabel("3.) Set Priority");
  Label3.style.top = "52%";
  sidebar.append(Label3);

  var Label4 = createLabel("4.) Camera Info");
  Label4.style.top = "77%";
  sidebar.append(Label4);

  var generate = document.getElementById("generate");

  generate.addEventListener("click", function() {
    switch (step) {
      case 0:
        Label1.style.color = "white";
        workingArea.addEventListener('click', createDotOnClick);
        step++
        break;
      case 1:
        workingArea.removeEventListener('click', createDotOnClick);
        workingArea.innerHTML = "";
        Label2.style.color = "white";
        step++;
        break;
      case 2:
        Label3.style.color = "white";
        step++;
        break;
      case 3:
        Label4.style.color = "white";
        step++;
        break;
      case 4:
        generate.innerHMTL = "Generate";
        break;
    }
  });
});